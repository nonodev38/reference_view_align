bl_info = {
    "name": "Reference View Align",
    "author": "Claude",
    "version": (1, 9, 4),
    "blender": (2, 90, 0),
    "location": "Vue 3D > Barre latérale (N) > Onglet Référence | Menu Objet",
    "description": "Aligne les images de référence (Empty image) sur la vue active ou une vue choisie, "
                   "les ramène au curseur 3D (par axe) et règle leur affichage",
    "category": "3D View",
}

import math
import os
import re
import traceback
import bpy
import bmesh
from bpy.app.handlers import persistent
from mathutils import Euler, Matrix

# --------------------------------------------------------------------------
# Vues standards : nom affiché + rotation de la vue (identique à Blender)
# --------------------------------------------------------------------------
_R = math.radians
VIEWS = {
    'FRONT':  ("Face (Front)",     Euler((_R(90), 0, 0)).to_quaternion()),
    'BACK':   ("Arrière (Back)",   Euler((_R(90), 0, _R(180))).to_quaternion()),
    'RIGHT':  ("Droite (Right)",   Euler((_R(90), 0, _R(90))).to_quaternion()),
    'LEFT':   ("Gauche (Left)",    Euler((_R(90), 0, _R(-90))).to_quaternion()),
    'TOP':    ("Dessus (Top)",     Euler((0, 0, 0)).to_quaternion()),
    'BOTTOM': ("Dessous (Bottom)", Euler((_R(180), 0, 0)).to_quaternion()),
}

VIEW_NAMES_EN = {
    'FRONT': "Front", 'BACK': "Back", 'RIGHT': "Right", 'LEFT': "Left",
    'TOP': "Top", 'BOTTOM': "Bottom", 'USER': "User", 'CAMERA': "Camera",
}

_last_rv3d = {"area": None}   # dernière vue 3D vue par le panneau
_known_refs = set()           # session_uid des images de référence déjà traitées/connues
_busy = {"flag": False}       # garde anti-récursion du handler
_state = {"init": False}      # liste des références connue ?


# --------------------------------------------------------------------------
# Utilitaires
# --------------------------------------------------------------------------
def get_view_info(rv3d):
    """Retourne (clé, libellé, type de projection) pour une region_3d."""
    proj = {'PERSP': "Perspective", 'ORTHO': "Orthographique",
            'CAMERA': "Caméra"}.get(rv3d.view_perspective, rv3d.view_perspective)
    if rv3d.view_perspective == 'CAMERA':
        return 'CAMERA', "Vue caméra", proj
    q = rv3d.view_rotation
    for key, (label, ref) in VIEWS.items():
        if abs(q.dot(ref)) > 0.999:
            return key, label, proj
    return 'USER', "Vue libre (User)", proj


def find_view3d(context):
    area = context.area
    if area and area.type == 'VIEW_3D':
        return area.spaces.active.region_3d
    last = _last_rv3d["area"]
    if last is not None:
        try:
            return last.spaces.active.region_3d
        except Exception:
            _last_rv3d["area"] = None
    for win in context.window_manager.windows:
        for a in win.screen.areas:
            if a.type == 'VIEW_3D':
                return a.spaces.active.region_3d
    return None


_draw_handle = {"h": None}


def _track_view_area():
    """Appelé à chaque redessin d'une vue 3D : mémorise la vue réellement utilisée."""
    area = bpy.context.area
    if area is not None and area.type == 'VIEW_3D':
        _last_rv3d["area"] = area


def is_image_empty(obj):
    return obj.type == 'EMPTY' and obj.empty_display_type == 'IMAGE'


def get_targets(context):
    """Références visées : sélection (ou active) ou toutes celles de la scène."""
    scene = context.scene
    if scene.refalign_target == 'ALL':
        return [o for o in scene.objects if is_image_empty(o)]
    targets = [o for o in context.selected_objects if is_image_empty(o)]
    if not targets and context.object and is_image_empty(context.object):
        targets = [context.object]
    return targets


def orientation_from_view(rv3d):
    key = get_view_info(rv3d)[0]
    if key in VIEWS:
        return VIEWS[key][1]
    return rv3d.view_matrix.inverted().to_quaternion()


def apply_transform(obj, quat=None, cursor=None, axes=(True, True, True)):
    """Applique rotation (quat) et/ou position sur le curseur (par axe), en espace monde."""
    loc, rot, scale = obj.matrix_world.decompose()
    if quat is not None:
        rot = quat
    if cursor is not None:
        loc = loc.copy()
        for i in range(3):
            if axes[i]:
                loc[i] = cursor[i]
    obj.matrix_world = Matrix.LocRotScale(loc, rot, scale)
    # l'écartement mémorisé n'est plus valable si l'orientation change ou si son axe est recalé
    old_idx = obj.get("_refoffset_axis")
    if old_idx is not None and (quat is not None or (cursor is not None and axes[int(old_idx)])):
        obj.pop("_refoffset_axis", None)
        obj.pop("_refoffset", None)


# vue -> (réglage d'axe de la scène, signe) ; les vues inverses (Ctrl+1/3/7) prennent -distance
OFFSET_RULES = {
    'FRONT': ("refalign_axis_front", 1.0), 'BACK': ("refalign_axis_front", -1.0),
    'RIGHT': ("refalign_axis_right", 1.0), 'LEFT': ("refalign_axis_right", -1.0),
    'TOP': ("refalign_axis_top", 1.0), 'BOTTOM': ("refalign_axis_top", -1.0),
}


def set_view_offset(obj, key, scene):
    """Applique l'écartement de la vue ; retire d'abord l'écartement précédemment appliqué."""
    prop, sign = OFFSET_RULES[key]
    idx = "XYZ".index(getattr(scene, prop))
    new = sign * scene.refalign_offset_distance
    old_idx = obj.get("_refoffset_axis")
    old = obj.get("_refoffset", 0.0)
    loc, rot, scale = obj.matrix_world.decompose()
    loc = loc.copy()
    if old_idx is not None:
        loc[int(old_idx)] -= old
    loc[idx] += new
    obj.matrix_world = Matrix.LocRotScale(loc, rot, scale)
    obj["_refoffset_axis"] = idx
    obj["_refoffset"] = new


def remove_view_offset(obj):
    """Retire l'écartement mémorisé (utile avant de réorienter l'image)."""
    old_idx = obj.get("_refoffset_axis")
    if old_idx is None:
        return
    loc, rot, scale = obj.matrix_world.decompose()
    loc = loc.copy()
    loc[int(old_idx)] -= obj.get("_refoffset", 0.0)
    obj.matrix_world = Matrix.LocRotScale(loc, rot, scale)
    obj.pop("_refoffset_axis", None)
    obj.pop("_refoffset", None)


def apply_view_offset(obj, key, scene):
    """Écarte la référence à l'import selon la vue (négatif pour les vues inverses)."""
    if scene.refalign_offset and key in OFFSET_RULES:
        set_view_offset(obj, key, scene)


def view_key_of_object(obj):
    """Vue standard dans laquelle l'image est orientée (None si orientation libre)."""
    q = obj.matrix_world.to_quaternion()
    for key, (_label, ref) in VIEWS.items():
        if abs(q.dot(ref)) > 0.999:
            return key
    return None


def blueprint_view_keys(scene):
    """Parcourt la collection blueprint et retourne l'ensemble des vues (FRONT, TOP...)
    pour lesquelles une image de référence existe."""
    found = set()
    for obj in blueprint_refs(scene):
        key = view_key_of_object(obj)
        if key is not None:
            found.add(key)
    return found


# ordre et libellés des boutons de masquage (en haut du panneau)
HIDE_BUTTONS = [('FRONT', "Face"), ('BACK', "Arrière"), ('BOTTOM', "Dessous"),
                ('TOP', "Dessus"), ('LEFT', "Gauche"), ('RIGHT', "Droite")]


def view_refs(scene, key):
    """Images de la collection blueprint orientées dans la vue `key`."""
    return [o for o in blueprint_refs(scene) if view_key_of_object(o) == key]


def _is_hidden(obj):
    try:
        return obj.hide_get()
    except RuntimeError:        # objet absent du view layer (collection exclue)
        return False


def _on_offset_changed(self, context):
    """Slider de distance / axes : met à jour en direct les images de la collection."""
    if not self.refalign_offset:
        return
    for o in blueprint_refs(self):
        key = view_key_of_object(o)
        if key in OFFSET_RULES:
            set_view_offset(o, key, self)


def blueprint_refs(scene):
    """Images de référence contenues dans la collection choisie (sous-collections incluses)."""
    name = scene.refalign_collection_name.strip()
    coll = bpy.data.collections.get(name) if name else None
    if coll is None:
        return []
    return [o for o in coll.all_objects if is_image_empty(o)]


def apply_to_blueprint(scene):
    for o in blueprint_refs(scene):
        apply_import_defaults(o, scene)


def _on_display_changed(self, context):
    """Mode Auto : un réglage du haut est appliqué à toutes les images de la collection."""
    if self.refalign_mode == 'AUTO':
        apply_to_blueprint(self)


def apply_import_defaults(obj, scene):
    obj.use_empty_image_alpha = True
    obj.color[3] = scene.refalign_opacity
    obj.empty_image_depth = scene.refalign_depth
    obj.show_empty_image_perspective = scene.refalign_show_persp
    obj.show_empty_image_orthographic = scene.refalign_show_ortho


def rename_for_view(obj, key, scene):
    """Renomme l'objet avec le nom anglais de la vue (ex. Front, Top_photo)."""
    if not scene.refalign_rename:
        return
    target = VIEW_NAMES_EN.get(key, "User")
    if scene.refalign_keep_name:
        base = obj.get("_refbase")
        if not base:
            img = getattr(obj, "data", None)
            base = os.path.splitext(img.name)[0] if img else obj.name
            obj["_refbase"] = base
        target = "%s_%s" % (target, base)
    # déjà correct (ou avec suffixe .001 de Blender) : on ne touche à rien
    if re.fullmatch(re.escape(target) + r"(\.\d{3})?", obj.name):
        return
    obj.name = target


def _collection_in_scene(scene, coll):
    def walk(parent):
        for ch in parent.children:
            if ch == coll or walk(ch):
                return True
        return False
    return walk(scene.collection)


def move_to_collection(obj, scene, name=None):
    """Range l'objet dans la collection `name` (par défaut celle des références),
    créée si elle n'existe pas."""
    name = (name if name is not None else scene.refalign_collection_name).strip()
    if not name:
        return
    coll = bpy.data.collections.get(name)
    if coll is None:
        coll = bpy.data.collections.new(name)
    if not _collection_in_scene(scene, coll):
        scene.collection.children.link(coll)
    if coll in obj.users_collection and len(obj.users_collection) == 1:
        return
    if obj.name not in coll.objects:
        coll.objects.link(obj)
    for c in list(obj.users_collection):
        if c != coll:
            c.objects.unlink(obj)


def redraw_all(context):
    for win in context.window_manager.windows:
        for a in win.screen.areas:
            a.tag_redraw()


# --------------------------------------------------------------------------
# Opérateurs
# --------------------------------------------------------------------------
class REFALIGN_OT_align_to_view(bpy.types.Operator):
    bl_idname = "refalign.align_to_view"
    bl_label = "Aligner sur la vue active"
    bl_description = "Oriente les références face à la vue active " \
                     "(et les place au curseur 3D si l'option est cochée)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        scene = context.scene
        targets = get_targets(context)
        if not targets:
            self.report({'WARNING'}, "Aucune image de référence (Empty image) à traiter")
            return {'CANCELLED'}
        rv3d = context.space_data.region_3d
        quat = orientation_from_view(rv3d)
        key = get_view_info(rv3d)[0]
        cursor = scene.cursor.location if scene.refalign_use_cursor else None
        for obj in targets:
            apply_transform(obj, quat, cursor, scene.refalign_axes)
            obj["_refaligned"] = True
            rename_for_view(obj, key, scene)
        self.report({'INFO'}, "%d référence(s) alignée(s) sur : %s"
                    % (len(targets), get_view_info(rv3d)[1]))
        return {'FINISHED'}


class REFALIGN_OT_set_view(bpy.types.Operator):
    bl_idname = "refalign.set_view"
    bl_label = "Aligner sur une vue précise"
    bl_description = ("Oriente les références face à la vue choisie. Si le bouton est bleu (une image existe "
                      "déjà dans la collection pour cette vue), bascule seulement la vue 3D sans toucher "
                      "aux images (Ctrl+clic pour forcer la mise à jour)")
    bl_options = {'REGISTER', 'UNDO'}

    force: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    view: bpy.props.EnumProperty(
        name="Vue",
        items=[(k, v[0], "") for k, v in VIEWS.items()],
        default='FRONT')

    def invoke(self, context, event):
        self.force = event.ctrl
        return self.execute(context)

    def execute(self, context):
        scene = context.scene
        # Bouton bleu = une image existe déjà pour cette vue : on ne fait que basculer la vue 3D
        if not self.force and self.view in blueprint_view_keys(scene):
            if context.area and context.area.type == 'VIEW_3D':
                bpy.ops.view3d.view_axis(type=self.view)
            self.report({'INFO'}, "Vue : %s (images inchangées, Ctrl+clic pour les mettre à jour)"
                        % VIEWS[self.view][0])
            return {'FINISHED'}
        targets = get_targets(context)
        if not targets:
            self.report({'WARNING'}, "Aucune image de référence (Empty image) à traiter")
            return {'CANCELLED'}
        quat = VIEWS[self.view][1]
        cursor = scene.cursor.location if scene.refalign_use_cursor else None
        for obj in targets:
            remove_view_offset(obj)          # repart de la position sans ancien écartement
            apply_transform(obj, quat, cursor, scene.refalign_axes)
            obj["_refaligned"] = True
            rename_for_view(obj, self.view, scene)
            apply_view_offset(obj, self.view, scene)   # distance de la vue si l'option est cochée
        if scene.refalign_switch_view and context.area and context.area.type == 'VIEW_3D':
            bpy.ops.view3d.view_axis(type=self.view)
        self.report({'INFO'}, "%d référence(s) orientée(s) : %s"
                    % (len(targets), VIEWS[self.view][0]))
        return {'FINISHED'}


class REFALIGN_OT_snap_to_cursor(bpy.types.Operator):
    bl_idname = "refalign.snap_to_cursor"
    bl_label = "Ramener au curseur 3D"
    bl_description = "Déplace les références sur le curseur 3D, uniquement sur les axes cochés " \
                     "(l'orientation n'est pas modifiée)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        targets = get_targets(context)
        if not targets:
            self.report({'WARNING'}, "Aucune image de référence (Empty image) à traiter")
            return {'CANCELLED'}
        if not any(scene.refalign_axes):
            self.report({'WARNING'}, "Coche au moins un axe (X, Y ou Z)")
            return {'CANCELLED'}
        for obj in targets:
            apply_transform(obj, None, scene.cursor.location, scene.refalign_axes)
        self.report({'INFO'}, "%d référence(s) ramenée(s) au curseur" % len(targets))
        return {'FINISHED'}


class REFALIGN_OT_to_collection(bpy.types.Operator):
    bl_idname = "refalign.to_collection"
    bl_label = "Ranger dans la collection"
    bl_description = "Déplace les références dans la collection choisie (créée si elle n'existe pas)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        if not scene.refalign_collection_name.strip():
            self.report({'WARNING'}, "Indique un nom de collection")
            return {'CANCELLED'}
        targets = get_targets(context)
        if not targets:
            self.report({'WARNING'}, "Aucune image de référence (Empty image) à traiter")
            return {'CANCELLED'}
        for obj in targets:
            move_to_collection(obj, scene)
        self.report({'INFO'}, "%d référence(s) rangée(s) dans « %s »"
                    % (len(targets), scene.refalign_collection_name))
        return {'FINISHED'}


# --------------------------------------------------------------------------
# Cube de référence
# Point zéro : bas du cube sur Z, centre du cube sur X, face du cube sur Y = 0
# --------------------------------------------------------------------------
def get_cube(scene):
    for o in scene.objects:
        if o.get("_refcube"):
            return o
    return None


def _cube_geometry(scene):
    sx, sy, sz = scene.refalign_cube_size
    y0, y1 = (0.0, sy) if scene.refalign_cube_front else (-sy, 0.0)
    xs, zs = (-sx / 2.0, sx / 2.0), (0.0, sz)
    verts = [(x, y, z) for z in zs for y in (y0, y1) for x in xs]
    # indices : z*4 + y*2 + x
    faces = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return verts, faces


def rebuild_cube_mesh(scene, cube):
    verts, faces = _cube_geometry(scene)
    me = cube.data
    me.clear_geometry()
    me.from_pydata(verts, [], faces)
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)   # normales vers l'extérieur
    bm.to_mesh(me)
    bm.free()
    me.update()


def _on_cube_size_changed(self, context):
    cube = get_cube(self)
    if cube is not None:
        rebuild_cube_mesh(self, cube)


def _on_cube_wire_changed(self, context):
    cube = get_cube(self)
    if cube is not None:
        cube.display_type = 'WIRE' if self.refalign_cube_wire else 'SOLID'


def _on_cube_pos_changed(self, context):
    cube = get_cube(self)
    if cube is not None:
        cube.location = self.refalign_cube_pos


def _on_cube_view_changed(self, context):
    """Slider « selon la vue » : fixe la coordonnée de l'axe lié à la vue active."""
    rv3d = find_view3d(context)
    if rv3d is None:
        return
    key = get_view_info(rv3d)[0]
    if key not in OFFSET_RULES:
        return
    prop, sign = OFFSET_RULES[key]
    idx = "XYZ".index(getattr(self, prop))
    pos = list(self.refalign_cube_pos)
    pos[idx] = sign * self.refalign_cube_view_dist
    self.refalign_cube_pos = pos     # déclenche le déplacement du cube


class REFALIGN_OT_toggle_view(bpy.types.Operator):
    bl_idname = "refalign.toggle_view"
    bl_label = "Masquer / afficher les images d'une vue"
    bl_description = "Masque (ou ré-affiche) les images de la collection blueprint orientées dans cette vue"
    bl_options = {'REGISTER', 'UNDO'}

    view: bpy.props.EnumProperty(
        name="Vue", items=[(k, v[0], "") for k, v in VIEWS.items()], default='FRONT')

    def execute(self, context):
        refs = view_refs(context.scene, self.view)
        if not refs:
            self.report({'WARNING'}, "Aucune image « %s » dans la collection" % VIEWS[self.view][0])
            return {'CANCELLED'}
        hide = not all(_is_hidden(o) for o in refs)    # tout masqué -> on ré-affiche
        for o in refs:
            try:
                o.hide_set(hide)
            except RuntimeError:
                pass
        redraw_all(context)
        return {'FINISHED'}


class REFALIGN_OT_add_cube(bpy.types.Operator):
    bl_idname = "refalign.add_cube"
    bl_label = "Ajouter le cube ref"
    bl_description = "Crée le cube de référence (bas sur Z=0, centré sur X, face sur Y=0) ; " \
                     "s'il existe déjà, le remet au point zéro"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        cube = get_cube(scene)
        if cube is None:
            me = bpy.data.meshes.new("Cube_ref")
            cube = bpy.data.objects.new("Cube_ref", me)
            cube["_refcube"] = True
            scene.collection.objects.link(cube)
            rebuild_cube_mesh(scene, cube)
            cube.display_type = 'WIRE' if scene.refalign_cube_wire else 'SOLID'
        # le cube a sa propre collection (créée si besoin), distincte de blueprint
        move_to_collection(cube, scene, scene.refalign_cube_collection)
        reset_cube_to_zero(context, reset_rotation=True)
        for o in context.selected_objects:
            o.select_set(False)
        try:
            cube.select_set(True)
            context.view_layer.objects.active = cube
        except RuntimeError:
            pass
        return {'FINISHED'}


def reset_cube_to_zero(context, reset_rotation=False):
    """Remet le cube et les champs au point zéro, sans dépendre des callbacks de propriétés."""
    scene = context.scene
    cube = get_cube(scene)
    scene.refalign_cube_view_dist = 0.0
    scene.refalign_cube_pos = (0.0, 0.0, 0.0)
    if cube is not None:
        cube.location = (0.0, 0.0, 0.0)
        if reset_rotation:
            cube.rotation_euler = (0.0, 0.0, 0.0)
        cube.update_tag()
    redraw_all(context)
    return cube


class REFALIGN_OT_cube_zero(bpy.types.Operator):
    bl_idname = "refalign.cube_zero"
    bl_label = "Remettre à zéro"
    bl_description = "Remet le cube ref au point zéro (X, Y, Z = 0) et le slider de vue à 0"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if reset_cube_to_zero(context) is None:
            self.report({'WARNING'}, "Pas de cube ref : clique d'abord sur « Ajouter le cube ref »")
            return {'CANCELLED'}
        return {'FINISHED'}


class REFALIGN_OT_refresh(bpy.types.Operator):
    bl_idname = "refalign.refresh"
    bl_label = "Actualiser"
    bl_description = "Actualise la vue active et la liste des références ; en mode Auto, ré-applique les réglages d'affichage à toutes les images de la collection"

    def execute(self, context):
        try:
            _populate_known()
        except Exception:
            pass
        if context.area and context.area.type == 'VIEW_3D':
            _last_rv3d["area"] = context.area
        if context.scene.refalign_mode == 'AUTO':
            apply_to_blueprint(context.scene)
        redraw_all(context)
        return {'FINISHED'}


# --------------------------------------------------------------------------
# Panneaux
# --------------------------------------------------------------------------
class REFALIGN_PT_main(bpy.types.Panel):
    bl_label = "Référence : alignement"
    bl_idname = "REFALIGN_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Référence"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rv3d = context.space_data.region_3d
        _last_rv3d["area"] = context.area

        # --- tout en haut : masquer / afficher les images par vue ---
        grid = layout.grid_flow(columns=2, align=True)
        for vkey, vname in HIDE_BUTTONS:
            refs = view_refs(scene, vkey)
            hidden = bool(refs) and all(_is_hidden(o) for o in refs)
            cell = grid.row(align=True)
            cell.enabled = bool(refs)
            text = ("Afficher " if hidden else "Masquer ") + vname
            icon = 'HIDE_ON' if hidden else 'HIDE_OFF'
            try:
                op = cell.operator("refalign.toggle_view", text=text, icon=icon, depress=hidden)
            except TypeError:
                op = cell.operator("refalign.toggle_view", text=text, icon=icon)
            op.view = vkey
        layout.separator()

        key, label, proj = get_view_info(rv3d)
        box = layout.box()
        row = box.row()
        row.label(text="Vue active :", icon='VIEW3D')
        row.operator("refalign.refresh", text="", icon='FILE_REFRESH')
        box.label(text=label)
        box.label(text="Projection : " + proj)

        layout.prop(scene, "refalign_target", text="Cible")
        n = len(get_targets(context))
        layout.label(text="%d référence(s) visée(s)" % n, icon='IMAGE_REFERENCE')

        layout.separator()
        layout.label(text="À l'import :")
        layout.prop(scene, "refalign_auto")
        disp = layout.column()
        disp.enabled = scene.refalign_mode == 'AUTO'   # grisé en mode Manuel
        col = disp.column(align=True)
        col.prop(scene, "refalign_opacity", slider=True)
        col.prop(scene, "refalign_depth", text="Profondeur")
        row = disp.row(align=True)
        row.prop(scene, "refalign_show_persp", text="Perspective", toggle=True)
        row.prop(scene, "refalign_show_ortho", text="Orthographique", toggle=True)
        if scene.refalign_mode != 'AUTO':
            layout.label(text="Mode Manuel : réglages par image (Image active)", icon='INFO')

        box = layout.box()
        box.prop(scene, "refalign_offset")
        sub = box.column()
        sub.active = scene.refalign_offset
        sub.prop(scene, "refalign_offset_distance", text="Distance", slider=True)
        for prop, label in (("refalign_axis_front", "Face / Arrière"),
                            ("refalign_axis_right", "Droite / Gauche"),
                            ("refalign_axis_top", "Dessus / Dessous")):
            row = sub.row(align=True)
            row.label(text=label)
            row.prop(scene, prop, expand=True)
        sub.label(text="Vues inverses (Ctrl+1/3/7) : distance négative")
        sub.label(text="Appliqué en direct à la collection « %s »" % scene.refalign_collection_name,
                  icon='OUTLINER_COLLECTION')

        box = layout.box()
        box.prop(scene, "refalign_use_collection")
        sub = box.column()
        sub.active = scene.refalign_use_collection
        sub.prop(scene, "refalign_collection_name", text="Nom")
        box.operator("refalign.to_collection", icon='OUTLINER_COLLECTION')


class REFALIGN_PT_orient(bpy.types.Panel):
    bl_label = "Orientation"
    bl_idname = "REFALIGN_PT_orient"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Référence"
    bl_parent_id = "REFALIGN_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.operator("refalign.align_to_view", icon='ORIENTATION_VIEW')

        layout.label(text="Vue précise :")
        grid = layout.grid_flow(columns=2, align=True)
        present = blueprint_view_keys(scene)      # vues déjà présentes dans la collection
        for key, (label, _q) in VIEWS.items():
            text = label.split(" (")[0]
            try:
                op = grid.operator("refalign.set_view", text=text, depress=(key in present))
            except TypeError:                      # anciennes versions de Blender
                op = grid.operator("refalign.set_view", text=text)
            op.view = key
        layout.prop(scene, "refalign_switch_view")

        layout.separator()
        layout.prop(scene, "refalign_rename")
        sub = layout.row()
        sub.active = scene.refalign_rename
        sub.prop(scene, "refalign_keep_name")


class REFALIGN_PT_position(bpy.types.Panel):
    bl_label = "Position (curseur 3D)"
    bl_idname = "REFALIGN_PT_position"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Référence"
    bl_parent_id = "REFALIGN_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "refalign_use_cursor")
        row = layout.row(align=True)
        row.label(text="Axes :")
        for i, name in enumerate("XYZ"):
            row.prop(scene, "refalign_axes", index=i, text=name, toggle=True)
        layout.operator("refalign.snap_to_cursor", icon='PIVOT_CURSOR')


class REFALIGN_PT_active(bpy.types.Panel):
    bl_label = "Image active"
    bl_idname = "REFALIGN_PT_active"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Référence"
    bl_parent_id = "REFALIGN_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "refalign_mode", expand=True)
        auto = scene.refalign_mode == 'AUTO'
        if auto:
            n = len(blueprint_refs(scene))
            layout.label(text="Réglages du haut appliqués à toute la collection « %s » (%d)"
                         % (scene.refalign_collection_name, n), icon='OUTLINER_COLLECTION')

        obj = context.object
        if obj is None or not is_image_empty(obj):
            layout.label(text="Sélectionne une image de référence", icon='INFO')
            return
        col = layout.column()
        col.enabled = not auto          # grisé en mode Auto
        col.label(text=obj.name, icon='IMAGE_DATA')
        col.prop(obj, "use_empty_image_alpha", text="Transparence")
        sub = col.row()
        sub.active = obj.use_empty_image_alpha
        sub.prop(obj, "color", index=3, text="Opacité", slider=True)
        col.prop(obj, "empty_display_size", text="Taille")
        col.prop(obj, "empty_image_depth", text="Profondeur")
        col.prop(obj, "show_in_front", text="Au premier plan")
        c2 = col.column(align=True)
        c2.prop(obj, "show_empty_image_orthographic", text="Visible en orthographique")
        c2.prop(obj, "show_empty_image_perspective", text="Visible en perspective")


class REFALIGN_PT_cube(bpy.types.Panel):
    bl_label = "Cube ref"
    bl_idname = "REFALIGN_PT_cube"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Référence"
    bl_parent_id = "REFALIGN_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        exists = get_cube(scene) is not None

        row = layout.row(align=True)
        row.operator("refalign.add_cube", icon='CUBE',
                     text="Remettre au zéro" if exists else "Ajouter le cube ref")
        if not exists:
            layout.label(text="Zéro : bas du cube (Z), centre (X), face (Y)", icon='INFO')

        col = layout.column(align=True)
        col.label(text="Taille :")
        col.prop(scene, "refalign_cube_size", text="")
        layout.prop(scene, "refalign_cube_front")
        layout.prop(scene, "refalign_cube_wire")
        layout.prop(scene, "refalign_cube_collection", text="Collection", icon='OUTLINER_COLLECTION')

        box = layout.box()
        rv3d = context.space_data.region_3d
        key, vlabel, _p = get_view_info(rv3d)
        if key in OFFSET_RULES:
            prop, sign = OFFSET_RULES[key]
            axis = getattr(scene, prop)
            box.label(text="Vue : %s → axe %s%s" % (vlabel.split(" (")[0], "-" if sign < 0 else "", axis))
        else:
            box.label(text="Vue libre : le slider est sans effet", icon='INFO')
        box.prop(scene, "refalign_cube_view_dist", text="Déplacement (vue)", slider=True)
        box.label(text="Position (tape une valeur) :")
        box.prop(scene, "refalign_cube_pos", text="")
        box.operator("refalign.cube_zero", icon='LOOP_BACK')


def menu_func(self, context):
    self.layout.separator()
    self.layout.operator("refalign.align_to_view", icon='ORIENTATION_VIEW')
    self.layout.operator("refalign.snap_to_cursor", icon='PIVOT_CURSOR')


# --------------------------------------------------------------------------
# Auto-alignement lors du glisser-déposer / ajout d'une image de référence
# --------------------------------------------------------------------------
def _current_refs():
    """{session_uid: objet} des images de référence. Peut lever AttributeError si
    bpy.data est encore restreint (activation de l'addon)."""
    return {o.session_uid: o for o in bpy.data.objects if is_image_empty(o)}


def _populate_known():
    _known_refs.clear()
    _known_refs.update(_current_refs().keys())
    _state["init"] = True


def _deferred_init():
    try:
        _populate_known()
    except Exception:
        _state["init"] = False
        return 0.5
    return None


@persistent
def on_load_post(_dummy):
    _state["init"] = False
    try:
        _populate_known()
    except Exception:
        pass


@persistent
def on_depsgraph_update(scene, depsgraph):
    try:
        _on_depsgraph_update(scene, depsgraph)
    except Exception:
        _busy["flag"] = False
        traceback.print_exc()


def _step(label, func, *args):
    """Exécute une étape ; une erreur n'empêche pas les étapes suivantes."""
    try:
        func(*args)
    except Exception:
        print("[Reference View Align] étape '%s' en erreur :" % label)
        traceback.print_exc()


def _on_depsgraph_update(scene, depsgraph):
    if _busy["flag"]:
        return
    if not _state["init"]:
        try:
            _populate_known()
        except AttributeError:
            pass
        return
    if not any(isinstance(u.id, bpy.types.Object) for u in depsgraph.updates):
        return
    try:
        current = _current_refs()
    except AttributeError:
        return
    # On compare des identifiants de session (et non des noms) : un nom réutilisé
    # après suppression / annulation (Ctrl+Z) ne fait plus passer à côté d'une nouvelle image.
    new_ids = set(current) - _known_refs
    _known_refs.update(current.keys())
    if not new_ids or not getattr(scene, "refalign_auto", False):
        return

    rv3d = find_view3d(bpy.context)
    quat = key = None
    if rv3d is not None:
        quat = orientation_from_view(rv3d)
        key = get_view_info(rv3d)[0]
    cursor = scene.cursor.location if scene.refalign_use_cursor else None
    _busy["flag"] = True
    try:
        for uid in new_ids:
            obj = current[uid]
            if obj.get("_refaligned"):
                continue
            # Chaque étape est indépendante : l'échec de l'une ne bloque pas les autres
            _step("position/orientation", apply_transform, obj, quat, cursor, scene.refalign_axes)
            if key is not None:
                _step("écartement", apply_view_offset, obj, key, scene)
            if scene.refalign_mode == 'AUTO':
                _step("opacité/profondeur", apply_import_defaults, obj, scene)
            obj["_refaligned"] = True
            if key is not None:
                _step("renommage", rename_for_view, obj, key, scene)
            if scene.refalign_use_collection:
                _step("collection", move_to_collection, obj, scene)
    finally:
        _busy["flag"] = False


# --------------------------------------------------------------------------
classes = (
    REFALIGN_OT_align_to_view,
    REFALIGN_OT_set_view,
    REFALIGN_OT_snap_to_cursor,
    REFALIGN_OT_to_collection,
    REFALIGN_OT_toggle_view,
    REFALIGN_OT_add_cube,
    REFALIGN_OT_cube_zero,
    REFALIGN_OT_refresh,
    REFALIGN_PT_main,
    REFALIGN_PT_orient,
    REFALIGN_PT_cube,
    REFALIGN_PT_position,
    REFALIGN_PT_active,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    S = bpy.types.Scene
    S.refalign_auto = bpy.props.BoolProperty(
        name="Alignement auto à l'import",
        description="Aligne automatiquement les nouvelles images de référence sur la vue active",
        default=True)
    S.refalign_use_cursor = bpy.props.BoolProperty(
        name="Placer au curseur 3D",
        description="Positionne aussi la référence sur le curseur 3D lors de l'alignement",
        default=True)
    S.refalign_axes = bpy.props.BoolVectorProperty(
        name="Axes", size=3, default=(True, True, True), subtype='XYZ',
        description="Axes sur lesquels la position est ramenée au curseur 3D")
    S.refalign_target = bpy.props.EnumProperty(
        name="Cible",
        items=[('SELECTED', "Sélection", "Références sélectionnées (ou active)"),
               ('ALL', "Toutes", "Toutes les références de la scène")],
        default='SELECTED')
    S.refalign_switch_view = bpy.props.BoolProperty(
        name="Basculer aussi la vue 3D",
        description="Change aussi la vue du viewport lors d'un alignement sur une vue précise",
        default=False)
    S.refalign_rename = bpy.props.BoolProperty(
        name="Renommer avec le nom de la vue",
        description="Renomme la référence avec le nom anglais de la vue (Front, Back, Left, Right, Top, Bottom...)",
        default=True)
    S.refalign_keep_name = bpy.props.BoolProperty(
        name="Garder le nom de l'image",
        description="Ajoute le nom de l'image après le nom de la vue (ex. Front_photo)",
        default=False)
    axis_items = [('X', "X", ""), ('Y', "Y", ""), ('Z', "Z", "")]
    S.refalign_offset = bpy.props.BoolProperty(
        name="Écarter à l'import selon la vue",
        description="Décale la référence importée selon la vue, sur l'axe choisi ; "
                    "à l'activation, applique aussitôt la distance aux images de la collection",
        default=True, update=_on_offset_changed)
    S.refalign_offset_distance = bpy.props.FloatProperty(
        name="Distance", default=6.0, min=-1000.0, max=1000.0,
        soft_min=0.0, soft_max=20.0, subtype='DISTANCE', unit='LENGTH',
        update=_on_offset_changed,
        description="Distance d'écartement, appliquée en direct aux images de la collection "
                    "(inversée pour Arrière, Gauche et Dessous)")
    S.refalign_axis_front = bpy.props.EnumProperty(
        name="Axe Face/Arrière", items=axis_items, default='Y', update=_on_offset_changed,
        description="Axe d'écartement en vue de face (et arrière, en négatif)")
    S.refalign_axis_right = bpy.props.EnumProperty(
        name="Axe Droite/Gauche", items=axis_items, default='X', update=_on_offset_changed,
        description="Axe d'écartement en vue de droite (et gauche, en négatif)")
    S.refalign_axis_top = bpy.props.EnumProperty(
        name="Axe Dessus/Dessous", items=axis_items, default='Z', update=_on_offset_changed,
        description="Axe d'écartement en vue de dessus (et dessous, en négatif)")
    S.refalign_cube_size = bpy.props.FloatVectorProperty(
        name="Taille du cube", size=3, default=(1.0, 1.0, 1.0), min=0.001,
        subtype='XYZ_LENGTH', unit='LENGTH', update=_on_cube_size_changed,
        description="Dimensions du cube de référence (X, Y, Z)")
    S.refalign_cube_pos = bpy.props.FloatVectorProperty(
        name="Position du cube", size=3, default=(0.0, 0.0, 0.0),
        subtype='TRANSLATION', unit='LENGTH', update=_on_cube_pos_changed,
        description="Position du point zéro du cube (X, Y, Z)")
    S.refalign_cube_view_dist = bpy.props.FloatProperty(
        name="Déplacement selon la vue", default=0.0, min=-1000.0, max=1000.0,
        soft_min=-20.0, soft_max=20.0, subtype='DISTANCE', unit='LENGTH',
        update=_on_cube_view_changed,
        description="Déplace le cube sur l'axe lié à la vue active (mêmes axes que l'écartement des "
                    "images ; négatif pour Arrière, Gauche et Dessous)")
    S.refalign_cube_front = bpy.props.BoolProperty(
        name="Face avant (-Y) à Y = 0", default=True, update=_on_cube_size_changed,
        description="Coché : la face avant du cube est à Y = 0 et le cube s'étend vers +Y. "
                    "Décoché : la face arrière est à Y = 0 et le cube s'étend vers -Y")
    S.refalign_cube_collection = bpy.props.StringProperty(
        name="Collection du cube", default="cube ref",
        description="Collection dans laquelle le cube ref est rangé (créée si elle n'existe pas)")
    S.refalign_cube_wire = bpy.props.BoolProperty(
        name="Affichage fil de fer", default=True, update=_on_cube_wire_changed)
    S.refalign_use_collection = bpy.props.BoolProperty(
        name="Ranger dans une collection",
        description="Range automatiquement les nouvelles références dans la collection ci-dessous "
                    "(créée si elle n'existe pas)",
        default=True)
    S.refalign_collection_name = bpy.props.StringProperty(
        name="Collection", default="blueprint",
        description="Nom de la collection des références")
    S.refalign_show_persp = bpy.props.BoolProperty(
        name="Visible en perspective",
        description="Les nouvelles références sont visibles en vue perspective",
        default=True, update=_on_display_changed)
    S.refalign_show_ortho = bpy.props.BoolProperty(
        name="Visible en orthographique",
        description="Les nouvelles références sont visibles en vue orthographique",
        default=True, update=_on_display_changed)
    S.refalign_mode = bpy.props.EnumProperty(
        name="Mode",
        items=[('AUTO', "Auto", "Les réglages du haut s'appliquent à toutes les images de la collection"),
               ('MANUAL', "Manuel", "Réglages image par image ; les réglages du haut sont désactivés")],
        default='AUTO', update=_on_display_changed)
    S.refalign_opacity = bpy.props.FloatProperty(
        name="Opacité", min=0.0, max=1.0, default=0.5, update=_on_display_changed,
        description="Opacité appliquée aux nouvelles références importées")
    S.refalign_depth = bpy.props.EnumProperty(
        name="Profondeur",
        items=[('DEFAULT', "Par défaut", ""),
               ('FRONT', "Devant", "Toujours devant les objets"),
               ('BACK', "Derrière", "Toujours derrière les objets")],
        default='DEFAULT', update=_on_display_changed)
    bpy.types.VIEW3D_MT_object.append(menu_func)
    _draw_handle["h"] = bpy.types.SpaceView3D.draw_handler_add(
        _track_view_area, (), 'WINDOW', 'POST_PIXEL')
    bpy.app.handlers.load_post.append(on_load_post)
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)
    bpy.app.timers.register(_deferred_init, first_interval=0.2)


def unregister():
    if bpy.app.timers.is_registered(_deferred_init):
        bpy.app.timers.unregister(_deferred_init)
    if on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph_update)
    if on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(on_load_post)
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    if _draw_handle["h"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle["h"], 'WINDOW')
        _draw_handle["h"] = None
    S = bpy.types.Scene
    for p in ("refalign_cube_collection", "refalign_cube_wire", "refalign_cube_front", "refalign_cube_view_dist",
              "refalign_cube_pos", "refalign_cube_size", "refalign_mode", "refalign_show_ortho", "refalign_show_persp", "refalign_axis_top", "refalign_axis_right", "refalign_axis_front",
              "refalign_offset_distance", "refalign_offset", "refalign_collection_name", "refalign_use_collection", "refalign_keep_name", "refalign_rename", "refalign_depth", "refalign_opacity", "refalign_switch_view",
              "refalign_target", "refalign_axes", "refalign_use_cursor", "refalign_auto"):
        delattr(S, p)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
